module.exports=[334505,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28frontend%29_advisory_page_actions_133c340.js.map