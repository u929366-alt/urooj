module.exports=[777323,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28frontend%29_about_page_actions_0r7qig6.js.map