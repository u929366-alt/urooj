module.exports=[218685,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28frontend%29_programs_%5Bslug%5D_page_actions_0t53npi.js.map