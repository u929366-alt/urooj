var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/(payload)/cms-api/[...slug]/route.js")
R.c("server/chunks/[root-of-the-server]__0danyev._.js")
R.c("server/chunks/_0bxsm0-._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_15oc6y6._.js")
R.c("server/chunks/_next-internal_server_app_(payload)_cms-api_[___slug]_route_actions_1ieqcod.js")
R.m(244516)
module.exports=R.m(244516).exports
