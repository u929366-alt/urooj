var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/(payload)/cms-api/graphql/route.js")
R.c("server/chunks/[root-of-the-server]__190wfsj._.js")
R.c("server/chunks/[root-of-the-server]__0ok59_o._.js")
R.c("server/chunks/_15oc6y6._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_next-internal_server_app_(payload)_cms-api_graphql_route_actions_1r9y4t-.js")
R.m(831176)
module.exports=R.m(831176).exports
