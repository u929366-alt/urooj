var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/newsletter/route.js")
R.c("server/chunks/[root-of-the-server]__1c0v57r._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_1sxm7p-._.js")
R.c("server/chunks/_next-internal_server_app_api_newsletter_route_actions_0w29l-i.js")
R.m(781233)
module.exports=R.m(781233).exports
