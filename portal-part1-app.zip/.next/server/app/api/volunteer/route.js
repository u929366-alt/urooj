var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/volunteer/route.js")
R.c("server/chunks/[root-of-the-server]__038cksh._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_1sxm7p-._.js")
R.c("server/chunks/_next-internal_server_app_api_volunteer_route_actions_18yy3k4.js")
R.m(662949)
module.exports=R.m(662949).exports
