var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/admission/route.js")
R.c("server/chunks/[root-of-the-server]__1_0iorw._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_1sxm7p-._.js")
R.c("server/chunks/_next-internal_server_app_api_admission_route_actions_1vuljho.js")
R.m(945651)
module.exports=R.m(945651).exports
