var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__12c8hpz._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_15vc_89.js")
R.m(977067)
module.exports=R.m(977067).exports
