var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__12eqllr._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_08hcpz0.js")
R.m(422945)
module.exports=R.m(422945).exports
