var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__214q9fb._.js")
R.c("server/chunks/[root-of-the-server]__1z2835r._.js")
R.m(489997)
module.exports=R.m(489997).exports
