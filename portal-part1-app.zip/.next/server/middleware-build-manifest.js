globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/hxbkCjhcSa0LN3iQxjlk4/_buildManifest.js",
    "static/hxbkCjhcSa0LN3iQxjlk4/_ssgManifest.js",
    "static/hxbkCjhcSa0LN3iQxjlk4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/37v5ulr6qjozi.js",
    "static/chunks/3r4kwx2m833kg.js",
    "static/chunks/34oyci46fsc5w.js",
    "static/chunks/06j3juy1u5a-6.js",
    "static/chunks/3nc6x0_y5iwnk.js",
    "static/chunks/turbopack-14m0wsz7d5hxt.js"
  ]
};
