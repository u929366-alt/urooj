globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/5ZJlygclnAONe7ggGBjy3/_buildManifest.js",
    "static/5ZJlygclnAONe7ggGBjy3/_ssgManifest.js",
    "static/5ZJlygclnAONe7ggGBjy3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/37v5ulr6qjozi.js",
    "static/chunks/2hu6ywaosjt9v.js",
    "static/chunks/17qtnw0uqah67.js",
    "static/chunks/34oyci46fsc5w.js",
    "static/chunks/228oj19jyxe16.js",
    "static/chunks/3nc6x0_y5iwnk.js",
    "static/chunks/turbopack-0b5cdry907mha.js"
  ]
};
