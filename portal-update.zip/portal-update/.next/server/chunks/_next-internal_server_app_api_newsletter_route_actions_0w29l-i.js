module.exports=[599062,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_newsletter_route_actions_0w29l-i.js.map